

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/MessageServlet")
public class MessageServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String content = request.getParameter("content");

        // Print the content to check before passing to the database
        System.out.println("Content to insert: " + content);

        // Call the method to insert the message into the database
        SqlConnection.insertMessage(content);

        // Prepare response
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<h1>Message added successfully!</h1>");
        out.println("<p><a href='index.html'>Back to form</a></p>");
    }
}
