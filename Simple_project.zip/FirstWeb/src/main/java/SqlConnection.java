

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
public class SqlConnection {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/simple_project";
    private static final String USER = "root"; // Update with your MySQL username
    private static final String PASS = "root"; // Update with your MySQL password

    public static void insertMessage(String message) {
        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            // 1. Register MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // 2. Open a connection
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
            System.out.println("Connected to database: " + DB_URL);

            // 3. Create SQL query
            String sql = "INSERT INTO messages (content) VALUES (?)";
            System.out.println("Preparing to execute: " + sql);

            // 4. Create PreparedStatement
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, message);

            // Print the message being inserted
            System.out.println("Inserting message: " + message);

            // 5. Execute the query
            int rowsInserted = stmt.executeUpdate();
            System.out.println("Rows inserted: " + rowsInserted);

        } catch (SQLException e) {
            System.err.println("SQLState: " + e.getSQLState());
            System.err.println("Error Code: " + e.getErrorCode());
            System.err.println("Message: " + e.getMessage());
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            // Clean up resources
            try {
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException se) {
                se.printStackTrace();
            }
        }
    }
}
