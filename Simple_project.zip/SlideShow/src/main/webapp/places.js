/**
 * 
 * implement arrays to navigate through slides using prevImg() and nextImage() functions. 
 */
// Define the array of places including the default image
const places = [ 
    {src: "images/img1.jpg", title: "Paris", desc: "Paris is known as the most romantic city in the world, and is home to some world famous sights that are constantly shown in travel magazines, movies, and other works of art."},
    {src: "images/img2.jpg", title: "London", desc: "London is famous for its rich architecture, including Buckingham Palace, Tower Bridge. Tea culture is also widespread in this city."},
    {src: "images/img3.jpg", title: "Tokyo", desc: "Tokyo blends futuristic skyscrapers and lively nightlife with ancient temples and serene gardens, creating a captivating mix of adrenaline and tranquility."},
    {src: "images/img4.jpg", title: "New York", desc: "New York City dazzles with iconic landmarks, vibrant culture, and diverse neighborhoods. Experience world-class museums, amazing food, and endless entertainment in this bustling metropolis."},
	{src: "images/img5.jpg", title: "Sydney", desc: "Sydney, Australia’s largest city, is famous for landmarks like the Opera House and Harbour Bridge. With beautiful beaches and a vibrant cultural scene, it provides a dynamic urban experience along a stunning coastline."},
	{
		src: "images/img6.jpg", title: "Jaipur", desc: "Jaipur, known as the Pink City, is famous for its beautiful palaces and forts, including the Hawa Mahal and Amber Fort. The city showcases rich Rajasthani culture and vibrant markets, making it a popular tourist destination."	
	}
	
];

// Start with the default image (index 0)
let currentIndex = 0;

// Function to load the current image, title, and description
function loadPlace(index) {
    const img = document.getElementById('slideshow-image');
    const title = document.getElementById('title');
    const desc = document.getElementById('desc-txt');
	const imageIdField = document.querySelector('input[name="imageId"]');

    // Load image, title, and description from the array based on the current index
    img.src = places[index].src;
    title.textContent = places[index].title;
    desc.textContent = places[index].desc;
	imageIdField.value = "img" + (index + 1);  // This generates "img1", "img2", etc.
}

// Function for the next image
function nextImage() {
    currentIndex = (currentIndex + 1) % places.length; // Move to next image, loop around if at the end
    loadPlace(currentIndex);
}

// Function for the previous image
function prevImage() {
    currentIndex = (currentIndex - 1 + places.length) % places.length; // Move to previous image, loop around if at the start
    loadPlace(currentIndex);
}

// Initial load (since the default image is already in HTML, we don't need to call loadPlace(0) initially)

