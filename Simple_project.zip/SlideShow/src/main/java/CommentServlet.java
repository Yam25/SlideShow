

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.*;

public class CommentServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Set character encoding to handle special characters in the comment
        request.setCharacterEncoding("UTF-8");

        // Get comment and image ID from the form
        String imageId = request.getParameter("imageId");
        String commentText = request.getParameter("commentText");

        // Basic validation to check if the comment is not empty
        if (commentText == null || commentText.trim().isEmpty()) {
            response.sendRedirect("index.html?error=empty_comment");
            return;
        }

        // Database connection and insertion
        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            // Load JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Connect to the database
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/simple_project", "root", "root");
            System.out.println("Connected to database: jdbc:mysql://localhost:3306/simple_project");

            // SQL query to insert the comment
            String sql = "INSERT INTO comments (image_id, comment_text) VALUES (?, ?)";
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, imageId);  // Set image ID
            stmt.setString(2, commentText);  // Set comment text

            // Execute the query
            stmt.executeUpdate();
            System.out.println("Comment added successfully: " + commentText); // Log comment addition

            // Redirect to the same page to see the updated comments
            response.sendRedirect("index.html");

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("error.html");  // Redirect to an error page in case of exception
        } finally {
            // Close the statement and connection to avoid memory leaks
            try { if (stmt != null) stmt.close(); } catch (SQLException e) { e.printStackTrace(); }
            try { if (conn != null) conn.close(); } catch (SQLException e) { e.printStackTrace(); }
        }
     
    }
}
