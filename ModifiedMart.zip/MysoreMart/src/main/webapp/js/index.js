$(document).ready(function () {
    $(".decrease-qty").on("click", function () {
        // Find the closest input element in the same product card
        const quantityInput = $(this).closest('.product').find('.quantity');
        let quantity = parseInt(quantityInput.val()); // Get the current quantity

        // Decrease the quantity if greater than 1
        if (quantity > 1) {
            quantity--; // Decrement
            quantityInput.val(quantity); // Update the input value
            updateCartTotal(); // Update cart total after quantity change
        }
    });

    $(".increase-qty").on("click", function () {
        // Find the closest input element in the same product card
        const quantityInput = $(this).closest('.product').find('.quantity');
        let quantity = parseInt(quantityInput.val()); // Get the current quantity

        quantity++; // Increment the quantity
        quantityInput.val(quantity); // Update the input value
        updateCartTotal(); // Update cart total after quantity change
    });

    $(".remove-item").on("click", function() {
        // Remove the closest product card
        $(this).closest('.product').remove();
        // Update the cart total after removing the item
        updateCartTotal();
    });

    function updateCartTotal() {
        let subtotal = 0; // Initialize subtotal
        $(".product").each(function () {
            const price = parseFloat($(this).data('price')); // Get product price from data attribute
            const quantity = parseInt($(this).find('.quantity').val()); // Get the current quantity
            subtotal += price * quantity; // Add to subtotal
        });

        const gstRate = 0.18; // GST rate (18%)
        const gst = subtotal * gstRate; // Calculate GST
        const total = subtotal + gst; // Calculate total including GST

        // Update the totals in the DOM
        $("#cart-total").text(total.toFixed(2)); // Update total in the DOM
        $("#subtotal").text(subtotal.toFixed(2)); // Update subtotal display
        $("#gst").text(gst.toFixed(2)); // Update GST display
    }
});
